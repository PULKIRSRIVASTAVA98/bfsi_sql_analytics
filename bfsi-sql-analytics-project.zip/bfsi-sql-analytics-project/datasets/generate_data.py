import csv
import random
from datetime import date, timedelta

random.seed(42)

# ---------- BRANCHES ----------
regions = ["North", "South", "East", "West", "Central"]
states = {
    "North": ["Delhi", "Punjab", "Haryana"],
    "South": ["Karnataka", "Tamil Nadu", "Kerala"],
    "East": ["West Bengal", "Odisha", "Bihar"],
    "West": ["Maharashtra", "Gujarat", "Rajasthan"],
    "Central": ["Madhya Pradesh", "Chhattisgarh"]
}
branches = []
branch_id = 1
for region in regions:
    for state in states[region]:
        for i in range(2):  # 2 branches per state
            branches.append({
                "branch_id": f"BR{branch_id:03d}",
                "branch_name": f"{state} Branch {i+1}",
                "region": region,
                "state": state
            })
            branch_id += 1

with open('/home/claude/bfsi-sql-analytics-project/datasets/branches.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=["branch_id","branch_name","region","state"])
    w.writeheader()
    w.writerows(branches)

# ---------- CUSTOMERS ----------
segments = ["Retail", "Premium", "Corporate", "Student"]
n_customers = 400
customers = []
for i in range(1, n_customers+1):
    cust_id = f"CUST{i:05d}"
    join_date = date(2019,1,1) + timedelta(days=random.randint(0, 2400))
    credit_score = random.randint(300, 900)
    segment = random.choices(segments, weights=[50,25,15,10])[0]
    branch = random.choice(branches)
    customers.append({
        "customer_id": cust_id,
        "segment": segment,
        "credit_score": credit_score,
        "join_date": join_date.isoformat(),
        "home_branch_id": branch["branch_id"]
    })

with open('/home/claude/bfsi-sql-analytics-project/datasets/customers.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=["customer_id","segment","credit_score","join_date","home_branch_id"])
    w.writeheader()
    w.writerows(customers)

# ---------- ACCOUNTS ----------
account_types = ["Savings", "Current", "Fixed Deposit", "Credit Card"]
accounts = []
acct_id = 1
for cust in customers:
    num_accounts = random.choices([1,2,3], weights=[50,35,15])[0]
    chosen_types = random.sample(account_types, num_accounts)
    for t in chosen_types:
        open_date = date.fromisoformat(cust["join_date"]) + timedelta(days=random.randint(0,60))
        if t == "Fixed Deposit":
            balance = round(random.uniform(50000, 1000000), 2)
        elif t == "Current":
            balance = round(random.uniform(5000, 500000), 2)
        elif t == "Credit Card":
            balance = round(random.uniform(-150000, 0), 2)  # outstanding as negative
        else:
            balance = round(random.uniform(1000, 300000), 2)
        status = random.choices(["Active","Dormant","Closed"], weights=[85,10,5])[0]
        accounts.append({
            "account_id": f"ACC{acct_id:06d}",
            "customer_id": cust["customer_id"],
            "account_type": t,
            "open_date": open_date.isoformat(),
            "balance": balance,
            "status": status,
            "branch_id": cust["home_branch_id"]
        })
        acct_id += 1

with open('/home/claude/bfsi-sql-analytics-project/datasets/accounts.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=["account_id","customer_id","account_type","open_date","balance","status","branch_id"])
    w.writeheader()
    w.writerows(accounts)

# ---------- TRANSACTIONS ----------
txn_types = ["Deposit", "Withdrawal", "Transfer", "Card Payment", "Loan Repayment"]
channels = ["ATM", "Branch", "Online", "Mobile App"]
active_accounts = [a for a in accounts if a["status"] == "Active"]

transactions = []
txn_id = 1
start_date = date(2024, 1, 1)
end_date = date(2026, 7, 31)
total_days = (end_date - start_date).days

for _ in range(15000):
    acct = random.choice(active_accounts)
    txn_date = start_date + timedelta(days=random.randint(0, total_days))
    txn_type = random.choices(txn_types, weights=[30,25,20,15,10])[0]
    channel = random.choices(channels, weights=[15,10,35,40])[0]
    if txn_type in ("Deposit",):
        amount = round(random.uniform(500, 100000), 2)
    elif txn_type == "Loan Repayment":
        amount = round(random.uniform(2000, 50000), 2)
    else:
        amount = round(random.uniform(200, 60000), 2)
    transactions.append({
        "transaction_id": f"TXN{txn_id:07d}",
        "account_id": acct["account_id"],
        "txn_date": txn_date.isoformat(),
        "txn_type": txn_type,
        "amount": amount,
        "channel": channel
    })
    txn_id += 1

transactions.sort(key=lambda x: x["txn_date"])

with open('/home/claude/bfsi-sql-analytics-project/datasets/transactions.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=["transaction_id","account_id","txn_date","txn_type","amount","channel"])
    w.writeheader()
    w.writerows(transactions)

# ---------- LOANS ----------
loan_types = ["Home Loan", "Personal Loan", "Auto Loan", "Education Loan", "Business Loan"]
loans = []
loan_id = 1
for cust in customers:
    if random.random() < 0.4:  # 40% of customers have a loan
        n_loans = random.choices([1,2], weights=[85,15])[0]
        for _ in range(n_loans):
            loan_type = random.choice(loan_types)
            sanctioned = {
                "Home Loan": random.uniform(1500000, 8000000),
                "Personal Loan": random.uniform(50000, 800000),
                "Auto Loan": random.uniform(200000, 1500000),
                "Education Loan": random.uniform(100000, 2000000),
                "Business Loan": random.uniform(500000, 5000000)
            }[loan_type]
            disbursed_date = date.fromisoformat(cust["join_date"]) + timedelta(days=random.randint(30, 800))
            tenure = random.choice([12,24,36,60,84,120,180,240])
            rate = round(random.uniform(7.5, 16.5), 2)
            status = random.choices(["Active","Closed","NPA"], weights=[70,25,5])[0]
            loans.append({
                "loan_id": f"LN{loan_id:05d}",
                "customer_id": cust["customer_id"],
                "loan_type": loan_type,
                "sanctioned_amount": round(sanctioned,2),
                "disbursed_date": disbursed_date.isoformat(),
                "tenure_months": tenure,
                "interest_rate": rate,
                "status": status
            })
            loan_id += 1

with open('/home/claude/bfsi-sql-analytics-project/datasets/loans.csv', 'w', newline='') as f:
    w = csv.DictWriter(f, fieldnames=["loan_id","customer_id","loan_type","sanctioned_amount","disbursed_date","tenure_months","interest_rate","status"])
    w.writeheader()
    w.writerows(loans)

print(f"branches: {len(branches)}")
print(f"customers: {len(customers)}")
print(f"accounts: {len(accounts)}")
print(f"transactions: {len(transactions)}")
print(f"loans: {len(loans)}")
