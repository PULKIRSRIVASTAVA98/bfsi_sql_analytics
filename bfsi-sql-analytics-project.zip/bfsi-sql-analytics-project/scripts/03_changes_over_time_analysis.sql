/*
===============================================================================
Changes Over Time Analysis
===============================================================================
Purpose: Spot trends and seasonality in transaction activity using
         DATE_TRUNC and grouped aggregation.
===============================================================================
*/

-- Monthly transaction volume and value trend
SELECT
    DATE_TRUNC('month', txn_date) AS txn_month,
    COUNT(*)                       AS txn_count,
    ROUND(SUM(amount), 2)          AS total_value
FROM transactions
GROUP BY txn_month
ORDER BY txn_month;

-- Year-over-year deposit growth
SELECT
    DATE_TRUNC('year', txn_date) AS txn_year,
    ROUND(SUM(amount), 2)         AS total_deposits
FROM transactions
WHERE txn_type = 'Deposit'
GROUP BY txn_year
ORDER BY txn_year;

-- Monthly new account openings — growth in customer acquisition
SELECT
    DATE_TRUNC('month', open_date) AS open_month,
    COUNT(*)                        AS new_accounts
FROM accounts
GROUP BY open_month
ORDER BY open_month;

-- Monthly channel mix trend — is digital adoption increasing over time?
SELECT
    DATE_TRUNC('month', txn_date) AS txn_month,
    channel,
    COUNT(*)                       AS txn_count
FROM transactions
GROUP BY txn_month, channel
ORDER BY txn_month, txn_count DESC;
