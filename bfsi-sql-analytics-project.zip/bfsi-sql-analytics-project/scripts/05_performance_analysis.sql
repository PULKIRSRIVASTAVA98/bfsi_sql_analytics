/*
===============================================================================
Performance Analysis
===============================================================================
Purpose: Compare current performance against prior periods using LAG(),
         and rank branches/products.
===============================================================================
*/

-- Month-over-month transaction value growth (%)
SELECT
    txn_month,
    total_value,
    LAG(total_value) OVER (ORDER BY txn_month)      AS prior_month_value,
    ROUND(100.0 * (total_value - LAG(total_value) OVER (ORDER BY txn_month))
        / NULLIF(LAG(total_value) OVER (ORDER BY txn_month), 0), 2) AS pct_change
FROM (
    SELECT
        DATE_TRUNC('month', txn_date) AS txn_month,
        SUM(amount)                    AS total_value
    FROM transactions
    GROUP BY txn_month
)
ORDER BY txn_month;

-- Branch performance: total deposit balance held, ranked
SELECT
    b.branch_name,
    b.region,
    COUNT(DISTINCT a.account_id)      AS num_accounts,
    ROUND(SUM(a.balance), 2)          AS total_balance,
    RANK() OVER (ORDER BY SUM(a.balance) DESC) AS branch_rank
FROM accounts a
JOIN branches b ON a.branch_id = b.branch_id
WHERE a.status = 'Active' AND a.account_type <> 'Credit Card'
GROUP BY b.branch_name, b.region
ORDER BY branch_rank;

-- Loan product performance vs. its own average sanctioned amount
SELECT
    loan_type,
    sanctioned_amount,
    ROUND(AVG(sanctioned_amount) OVER (PARTITION BY loan_type), 2) AS avg_for_type,
    CASE
        WHEN sanctioned_amount > AVG(sanctioned_amount) OVER (PARTITION BY loan_type)
            THEN 'Above Average'
        ELSE 'Below Average'
    END AS vs_avg
FROM loans;
