/*
===============================================================================
Data Segmentation
===============================================================================
Purpose: Group customers and accounts into meaningful bands using
         CASE + GROUP BY — the basis for targeting and risk analysis.
===============================================================================
*/

-- Customer segmentation by credit score band
SELECT
    CASE
        WHEN credit_score >= 750 THEN 'Excellent (750+)'
        WHEN credit_score >= 650 THEN 'Good (650-749)'
        WHEN credit_score >= 550 THEN 'Fair (550-649)'
        ELSE 'Poor (<550)'
    END AS credit_band,
    COUNT(*) AS num_customers
FROM customers
GROUP BY credit_band
ORDER BY num_customers DESC;

-- Account segmentation by balance tier
SELECT
    CASE
        WHEN balance >= 500000 THEN 'High Value (500K+)'
        WHEN balance >= 100000 THEN 'Mid Value (100K-500K)'
        WHEN balance >= 0      THEN 'Low Value (0-100K)'
        ELSE 'Negative (Credit Card Outstanding)'
    END AS balance_tier,
    account_type,
    COUNT(*)               AS num_accounts,
    ROUND(SUM(balance), 2) AS tier_total_balance
FROM accounts
WHERE status = 'Active'
GROUP BY balance_tier, account_type
ORDER BY tier_total_balance DESC;

-- Customer segment vs. average loan sanctioned amount
SELECT
    c.segment,
    COUNT(l.loan_id)                    AS num_loans,
    ROUND(AVG(l.sanctioned_amount), 2)  AS avg_loan_amount
FROM customers c
JOIN loans l ON c.customer_id = l.customer_id
GROUP BY c.segment
ORDER BY avg_loan_amount DESC;
