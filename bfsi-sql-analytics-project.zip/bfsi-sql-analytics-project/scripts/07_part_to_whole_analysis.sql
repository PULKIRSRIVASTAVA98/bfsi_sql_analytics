/*
===============================================================================
Part-to-Whole Analysis
===============================================================================
Purpose: What % of the total does each category represent — product mix,
         channel mix, and regional contribution.
===============================================================================
*/

-- Transaction channel contribution to total transaction value
SELECT
    channel,
    ROUND(SUM(amount), 2) AS channel_value,
    ROUND(100.0 * SUM(amount) / SUM(SUM(amount)) OVER (), 2) AS pct_of_total
FROM transactions
GROUP BY channel
ORDER BY pct_of_total DESC;

-- Loan type contribution to total active loan book
SELECT
    loan_type,
    ROUND(SUM(sanctioned_amount), 2) AS loan_type_value,
    ROUND(100.0 * SUM(sanctioned_amount) / SUM(SUM(sanctioned_amount)) OVER (), 2) AS pct_of_book
FROM loans
WHERE status = 'Active'
GROUP BY loan_type
ORDER BY pct_of_book DESC;

-- Regional contribution to total deposit balance
SELECT
    b.region,
    ROUND(SUM(a.balance), 2) AS region_balance,
    ROUND(100.0 * SUM(a.balance) / SUM(SUM(a.balance)) OVER (), 2) AS pct_of_total
FROM accounts a
JOIN branches b ON a.branch_id = b.branch_id
WHERE a.status = 'Active' AND a.account_type <> 'Credit Card'
GROUP BY b.region
ORDER BY pct_of_total DESC;
