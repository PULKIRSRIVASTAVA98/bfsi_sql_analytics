/*
===============================================================================
Cumulative Analysis
===============================================================================
Purpose: Running totals and moving averages — how deposit balances and
         loan disbursements accumulate over time.
===============================================================================
*/

-- Running total of deposits by month
SELECT
    txn_month,
    monthly_deposits,
    SUM(monthly_deposits) OVER (ORDER BY txn_month) AS running_total_deposits
FROM (
    SELECT
        DATE_TRUNC('month', txn_date) AS txn_month,
        SUM(amount)                    AS monthly_deposits
    FROM transactions
    WHERE txn_type = 'Deposit'
    GROUP BY txn_month
)
ORDER BY txn_month;

-- Cumulative loan disbursement over time, by loan type
SELECT
    disbursed_month,
    loan_type,
    monthly_disbursed,
    SUM(monthly_disbursed) OVER (
        PARTITION BY loan_type ORDER BY disbursed_month
    ) AS cumulative_disbursed
FROM (
    SELECT
        DATE_TRUNC('month', disbursed_date) AS disbursed_month,
        loan_type,
        SUM(sanctioned_amount)               AS monthly_disbursed
    FROM loans
    GROUP BY disbursed_month, loan_type
)
ORDER BY loan_type, disbursed_month;

-- 3-month moving average of transaction volume — smooths out noise
SELECT
    txn_month,
    txn_count,
    ROUND(AVG(txn_count) OVER (
        ORDER BY txn_month
        ROWS BETWEEN 2 PRECEDING AND CURRENT ROW
    ), 1) AS moving_avg_3mo
FROM (
    SELECT
        DATE_TRUNC('month', txn_date) AS txn_month,
        COUNT(*)                       AS txn_count
    FROM transactions
    GROUP BY txn_month
)
ORDER BY txn_month;
